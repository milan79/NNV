﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using NNV.Models;

namespace NNV.Controllers
{
    public class LoginController : Controller
    {
        //NNVContext context = new NNVContext();
        // GET: Login
        public ActionResult Index()
        {
            return View();
        }

        [HttpPost]
        public ActionResult Autorizacija (Clanovi userModel)
        {
            using (NNVContext context = new NNVContext())
            {
                var userDetails = context.Clanovi.Where(x => x.KorisnickoIme == userModel.KorisnickoIme && x.Lozinka == userModel.Lozinka).FirstOrDefault();
                if(userDetails == null)
                {
                    //userModel.LoginErrorMessage = "Погрешно корисничко име или лозинка.";
                    if (userModel.KorisnickoIme != null || userModel.Lozinka != null)
                        ViewBag.Message = string.Format("Погрешно корисничко име или лозинка.");
                    return View("Index", userModel);
                }
                else
                {
                    if (userDetails.KorisnickoIme == "Olja" && userDetails.Lozinka == "Olja")
                        return RedirectToAction("Index", "Admin");
                    Session["ClanID"] = userDetails.ClanID;
                    //Session["KorisnickoIme"] = userDetails.KorisnickoIme;
                    return RedirectToAction("NNV", "NNV");
                }
            }
        }

        public ActionResult Logout()
        {
            //int userID = (int)Session["ClanID"];
            Session.Abandon();
            return RedirectToAction("Index", "Login");
        }
    }
}